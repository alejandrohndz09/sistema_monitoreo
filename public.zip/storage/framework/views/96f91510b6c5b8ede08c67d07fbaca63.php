<?php
    use App\Models\Numeral;

    $numeraleshijos = $numeral->numerales;
    $numeraleshijos = Numeral::where('idNumeralPadre', $numeral->idNumeral)
        ->orderByRaw("CONCAT(LPAD(idNumeral, 10, '0'))")
        ->get();

?>

<?php $__currentLoopData = $numeraleshijos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $numeralHijo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="ms-4">
        <h5>
            <?php echo e($numeralHijo->idNumeral); ?>&nbsp;<?php echo e($numeralHijo->nombre); ?>

        </h5>

        <?php if($numeralHijo->descripcion): ?>
            <p><?php echo e($numeralHijo->descripcion); ?></p>
            <div class="btn-group mb-3 " role="group" aria-label="Evaluar <?php echo e($numeralHijo->nombre); ?>">
                <input type="radio" class="btn-check" name="monitoreo_<?php echo e($i); ?>"
                    id="btnradio-si-<?php echo e($numeralHijo->idNumeral); ?>" value="Sí" autocomplete="off"
                    <?php echo e(old('monitoreo_' . $i) == 'Sí' ? 'checked' : ''); ?>>
                <label class="btn btn-outline-dark " for="btnradio-si-<?php echo e($numeralHijo->idNumeral); ?>">Sí</label>

                <input type="radio" class="btn-check" name="monitoreo_<?php echo e($i); ?>"
                    id="btnradio-no-<?php echo e($numeralHijo->idNumeral); ?>" value="No" autocomplete="off"
                    <?php echo e(old('monitoreo_' . $i) == 'No' ? 'checked' : ''); ?>>
                <label class="btn btn-outline-dark" for="btnradio-no-<?php echo e($numeralHijo->idNumeral); ?>">No</label>

                <input type="radio" class="btn-check" name="monitoreo_<?php echo e($i); ?>"
                    id="btnradio-parcialmente-<?php echo e($numeralHijo->idNumeral); ?>" value="Parcialmente" autocomplete="off"
                    <?php echo e(old('monitoreo_' . $i) == 'Parcialmente' ? 'checked' : ''); ?>>
                <label class="btn btn-outline-dark"
                    for="btnradio-parcialmente-<?php echo e($numeralHijo->idNumeral); ?>">Parcialmente</label>
            </div>
            <?php $__errorArgs = ['monitoreo_' . $i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger d-block mt-1"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php
                $i++;
            ?>
        <?php endif; ?>

        <?php if($numeralHijo->numerales->isNotEmpty()): ?>
            <?php echo $__env->make('evaluaciones.parcial', ['numeral' => $numeralHijo, 'i'=>$i], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\sistema-monitoreo\resources\views/evaluaciones/parcial.blade.php ENDPATH**/ ?>