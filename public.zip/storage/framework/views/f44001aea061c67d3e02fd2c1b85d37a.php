<!--
=========================================================
* Soft UI Dashboard - v1.0.3
=========================================================

* Product Page: https://www.creative-tim.com/product/soft-ui-dashboard
* Copyright 2021 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://www.creative-tim.com/license)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
-->
<!DOCTYPE html>

<?php if(\Request::is('rtl')): ?>
    <html dir="rtl" lang="ar">
<?php else: ?>
    <html lang="en">
<?php endif; ?>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <?php if(env('IS_DEMO')): ?>
        <?php if (isset($component)) { $__componentOriginalb028e3c120f9eb4dcf5f37307a919070 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb028e3c120f9eb4dcf5f37307a919070 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.demo-metas','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('demo-metas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb028e3c120f9eb4dcf5f37307a919070)): ?>
<?php $attributes = $__attributesOriginalb028e3c120f9eb4dcf5f37307a919070; ?>
<?php unset($__attributesOriginalb028e3c120f9eb4dcf5f37307a919070); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb028e3c120f9eb4dcf5f37307a919070)): ?>
<?php $component = $__componentOriginalb028e3c120f9eb4dcf5f37307a919070; ?>
<?php unset($__componentOriginalb028e3c120f9eb4dcf5f37307a919070); ?>
<?php endif; ?>
    <?php endif; ?>

    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/img/logo-ct.png">
    <title>
        NormaSegura
    </title>
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
    <link rel="stylesheet"
        href="<?php echo e(url('https://cdn.jsdelivr.net/npm/sweetalert2@10.3.5/dist/sweetalert2.min.css')); ?>" />
    <!-- Nucleo Icons -->
    <link href="../assets/css/nucleo-icons.css" rel="stylesheet" />
    <link href="../assets/css/nucleo-svg.css" rel="stylesheet" />
    <!-- Font Awesome Icons -->
    
    
    <link href="../assets/css/nucleo-svg.css" rel="stylesheet" />
    <!-- CSS Files -->
    <?php echo $__env->yieldContent('styles'); ?>
    <link id="pagestyle" href="../assets/css/soft-ui-dashboard.css?v=1.0.3" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

</head>

<body style="overflow: visible;"
    class="g-sidenav-show  bg-gray-100 <?php echo e(\Request::is('rtl') ? 'rtl' : (Request::is('virtual-reality') ? 'virtual-reality' : '')); ?> ">
    <?php
        $user = auth()->user(); // Obtener el usuario logueado
    ?>

    <?php if(!$user || $user->estado == 0): ?>
    <?php
        // Cerrar la sesión del usuario
        Auth::logout();

        // Eliminar cualquier dato de la sesión
        session()->invalidate();
        session()->regenerateToken();
    ?>
    <script>
        // Redirigir al login si el usuario no existe o su estado es 0
        window.location.href = "<?php echo e(route('login')); ?>";
    </script>
    <?php endif; ?>

    <?php echo $__env->yieldContent('auth'); ?>



    <?php if(session()->has('success')): ?>
        <div x-data="{ show: true }" x-init="setTimeout(() => show = false, 4000)" x-show="show"
            class="position-fixed bg-success rounded right-3 text-sm py-2 px-4">
            <p class="m-0"><?php echo e(session('success')); ?></p>
        </div>
    <?php endif; ?>
    <!--   Core JS Files   -->
    <script src="../assets/js/core/popper.min.js"></script>
    <script src="../assets/js/core/bootstrap.min.js"></script>
    <script src="../assets/js/plugins/perfect-scrollbar.min.js"></script>
    <script src="../assets/js/plugins/smooth-scrollbar.min.js"></script>
    <script src="../assets/js/plugins/fullcalendar.min.js"></script>
    <script src="<?php echo e(asset('assets/js/plugins/chartjs.min.js')); ?>"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="<?php echo e(url('https://cdn.jsdelivr.net/npm/sweetalert2@10.3.5/dist/sweetalert2.min.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('rtl'); ?>
    <?php echo $__env->yieldPushContent('dashboard'); ?>
    <script>
        var win = navigator.platform.indexOf('Win') > -1;
        if (win && document.querySelector('#sidenav-scrollbar')) {
            var options = {
                damping: '0.5'
            }
            Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
        }
    </script>
    <script>
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            // iconColor: 'white',
        });
    </script>
    <?php if(session('alert')): ?>
        <script>
            Toast.fire({
                icon: "<?php echo e(session('alert')['type']); ?>",
                title: "<?php echo e(session('alert')['message']); ?>",
            });
        </script>
        <?php
            session()->forget('alert');
        ?>
    <?php endif; ?>
    <!-- Github buttons -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <!-- Control Center for Soft Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="../assets/js/soft-ui-dashboard.min.js?v=1.0.3"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\sistema-monitoreo\resources\views/layouts/app.blade.php ENDPATH**/ ?>