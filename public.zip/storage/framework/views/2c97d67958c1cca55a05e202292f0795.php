
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo asset('css/extras.css'); ?>" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/validaciones/jsEvaluacion.js')); ?>"></script>
    <script>
        // Función para llenar aleatoriamente los radios
        function llenarRadiosAleatorios() {
            const groups = document.querySelectorAll('.btn-group'); // Seleccionamos todos los grupos de botones
            
            groups.forEach(group => {
                const radios = group.querySelectorAll('input[type="radio"]'); // Seleccionamos todos los radios dentro del grupo
                const randomIndex = Math.floor(Math.random() * radios.length); // Seleccionamos un índice aleatorio
                radios[randomIndex].checked = true; // Marcamos el radio seleccionado aleatoriamente
            });
        }
    
        // Evento para llenar los radios cuando se hace clic en el botón
        document.getElementById('llenarAleatorio').addEventListener('click', llenarRadiosAleatorios);
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid ">
        <div class="row">
            <div class="col-lg-12">
                <div class="col-md-12 mb-lg-0 mb-4">
                    <form action="/evaluaciones" id="evaluacionForm" method="POST">
                        <?php echo csrf_field(); ?>
                        
                        <?php
                            use App\Models\Numeral;
                            $i = 0;
                        ?>
                        <?php $__currentLoopData = $numerales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $numeralPadre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card mb-4">
                                <div class="card-body">
                                    <h4 class="card-title">
                                        <?php echo e($numeralPadre->idNumeral); ?>.&nbsp;<?php echo e($numeralPadre->nombre); ?>

                                    </h4>

                                    <?php if($numeralPadre->descripcion): ?>
                                        <p class="card-text"><?php echo e($numeralPadre->descripcion); ?></p>
                                        <div class="btn-group mb-0" role="group"
                                            aria-label="Evaluar <?php echo e($numeralPadre->nombre); ?>">
                                            <input type="radio" class="btn-check" name="monitoreo_<?php echo e($i); ?>"
                                                id="btnradio-si-<?php echo e($numeralPadre->idNumeral); ?>" value="Sí"
                                                autocomplete="off" <?php echo e(old('monitoreo_' . $i) == 'Sí' ? 'checked' : ''); ?>>
                                            <label class="btn btn-outline-dark"
                                                for="btnradio-si-<?php echo e($numeralPadre->idNumeral); ?>">Sí</label>

                                            <input type="radio" class="btn-check" name="monitoreo_<?php echo e($i); ?>"
                                                id="btnradio-no-<?php echo e($numeralPadre->idNumeral); ?>" value="No"
                                                autocomplete="off" <?php echo e(old('monitoreo_' . $i) == 'No' ? 'checked' : ''); ?>>
                                            <label class="btn btn-outline-dark"
                                                for="btnradio-no-<?php echo e($numeralPadre->idNumeral); ?>">No</label>

                                            <input type="radio" class="btn-check" name="monitoreo_<?php echo e($i); ?>"
                                                id="btnradio-parcialmente-<?php echo e($numeralPadre->idNumeral); ?>"
                                                value="Parcialmente" autocomplete="off"
                                                <?php echo e(old('monitoreo_' . $i) == 'Parcialmente' ? 'checked' : ''); ?>>
                                            <label class="btn btn-outline-dark"
                                                for="btnradio-parcialmente-<?php echo e($numeralPadre->idNumeral); ?>">Parcialmente</label>
                                        </div>
                                        <span
                                            id="error-monitoreo_<?php echo e($i); ?>"class="text-danger d-block mt-1"></span>
                                        <?php
                                            $i++;
                                        ?>
                                    <?php endif; ?>

                                    <?php if($numeralPadre->numerales->isNotEmpty()): ?>
                                        <?php
                                            $numeraleshijos = $numeralPadre->numerales;
                                            $numeraleshijos = Numeral::where('idNumeralPadre', $numeralPadre->idNumeral)
                                                ->orderByRaw("CONCAT(LPAD(idNumeral, 10, '0'))")
                                                ->get();

                                        ?>

                                        <?php $__currentLoopData = $numeraleshijos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $numeralHijo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="ms-4 mb-6">
                                                <h5>
                                                    <?php echo e($numeralHijo->idNumeral); ?>&nbsp;<?php echo e($numeralHijo->nombre); ?>

                                                </h5>

                                                <?php if($numeralHijo->descripcion): ?>
                                                    <p><?php echo e($numeralHijo->descripcion); ?></p>
                                                    <div class="btn-group mb-0 " role="group"
                                                        aria-label="Evaluar <?php echo e($numeralHijo->nombre); ?>">
                                                        

                                                        <input type="radio" class="btn-check"
                                                            name="evaluacion[<?php echo e($numeralHijo->idNumeral); ?>]"
                                                            id="btnradio-si-<?php echo e($numeralHijo->idNumeral); ?>" value="Sí"
                                                            autocomplete="off">
                                                        <label class="btn btn-outline-dark mb-0"
                                                            for="btnradio-si-<?php echo e($numeralHijo->idNumeral); ?>">Sí</label>

                                                        <input type="radio" class="btn-check"
                                                            name="evaluacion[<?php echo e($numeralHijo->idNumeral); ?>]"
                                                            id="btnradio-no-<?php echo e($numeralHijo->idNumeral); ?>" value="No"
                                                            autocomplete="off">
                                                        <label class="btn btn-outline-dark mb-0"
                                                            for="btnradio-no-<?php echo e($numeralHijo->idNumeral); ?>">No</label>

                                                        <input type="radio" class="btn-check"
                                                            name="evaluacion[<?php echo e($numeralHijo->idNumeral); ?>]"
                                                            id="btnradio-parcialmente-<?php echo e($numeralHijo->idNumeral); ?>"
                                                            value="Parcialmente" autocomplete="off">
                                                        <label class="btn btn-outline-dark mb-0"
                                                            for="btnradio-parcialmente-<?php echo e($numeralHijo->idNumeral); ?>">Parcialmente</label>                                                      

                                                    </div>
                                                    
                                                    <span id="error-evaluacion-<?php echo e($numeralHijo->idNumeral); ?>"
                                                        class="text-danger d-block mt-1 mb-0"></span>
                                                    <?php
                                                        $i++;
                                                    ?>
                                                <?php endif; ?>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex justify-content-end">
                            <button id="llenarAleatorio" class="btn btn-secondary btn-lg mt-4 mb-0 me-3" style=" display: none" >Llenar Aleatoriamente</button>

                            <button type="submit" class="btn btn-icon bg-gradient-success btn-sm mt-4 mb-0">
                                <i class="fas fa-check text-xs"></i>&nbsp;&nbsp;Guardar</button>
                        </div>

                    </form>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user_type.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema-monitoreo\resources\views/evaluaciones/nueva.blade.php ENDPATH**/ ?>